"""
Document Loader Module

Loads documents from local filesystem and converts them to PIL Images
for downstream processing.
"""

from pathlib import Path
from typing import Union, List
from PIL import Image
import fitz  # PyMuPDF


class DocumentLoader:
    """
    Loads documents from local filesystem and converts to images.
    
    Supports PDF and common image formats (PNG, JPG, TIFF, BMP).
    PDF files are converted to images at 300 DPI for optimal OCR quality.
    """
    
    # Supported file formats
    SUPPORTED_FORMATS = ['.pdf', '.png', '.jpg', '.jpeg', '.tiff', '.tif', '.bmp']
    
    def __init__(self, dpi: int = 300):
        """
        Initialize the document loader.
        
        Args:
            dpi: DPI for PDF to image conversion (default: 300, optimal for OCR)
        """
        self.dpi = dpi
        self.supported_formats = self.SUPPORTED_FORMATS
    
    def load(self, file_path: Union[str, Path]) -> List[Image.Image]:
        """
        Load a document and return list of PIL Images (one per page).
        
        Args:
            file_path: Path to the document file
            
        Returns:
            List of PIL Image objects (RGB mode)
            
        Raises:
            FileNotFoundError: If file doesn't exist
            ValueError: If file format is not supported
            Exception: If document loading fails
        """
        file_path = Path(file_path)
        
        # Validate file exists
        if not file_path.exists():
            raise FileNotFoundError(f"File not found: {file_path}")
        
        # Validate file format
        if file_path.suffix.lower() not in self.supported_formats:
            raise ValueError(
                f"Unsupported format: {file_path.suffix}. "
                f"Supported formats: {', '.join(self.supported_formats)}"
            )
        
        try:
            # Handle PDF files
            if file_path.suffix.lower() == '.pdf':
                return self._load_pdf(file_path)
            
            # Handle image files
            else:
                return self._load_image(file_path)
                
        except Exception as e:
            raise Exception(f"Failed to load document {file_path}: {str(e)}")
    
    def _load_pdf(self, file_path: Path) -> List[Image.Image]:
        """
        Convert PDF pages to images using PyMuPDF.
        
        Args:
            file_path: Path to PDF file
            
        Returns:
            List of PIL Images, one per page
        """
        print(f"Converting PDF to images at {self.dpi} DPI...")
        
        # Open PDF document
        doc = fitz.open(str(file_path))
        images = []
        
        # Convert each page to image
        for page_num in range(len(doc)):
            page = doc[page_num]
            
            # Calculate zoom factor for desired DPI (default is 72 DPI)
            zoom = self.dpi / 72
            mat = fitz.Matrix(zoom, zoom)
            
            # Render page to pixmap
            pix = page.get_pixmap(matrix=mat)
            
            # Convert to PIL Image
            img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
            images.append(img)
        
        doc.close()
        return images
    
    def _load_image(self, file_path: Path) -> List[Image.Image]:
        """
        Load image file.
        
        Args:
            file_path: Path to image file
            
        Returns:
            List containing single PIL Image
        """
        img = Image.open(file_path)
        
        # Convert to RGB mode if necessary (handles RGBA, grayscale, etc.)
        if img.mode != 'RGB':
            img = img.convert('RGB')
        
        return [img]
    
    def get_document_info(self, file_path: Union[str, Path]) -> dict:
        """
        Get basic information about a document without fully loading it.
        
        Args:
            file_path: Path to the document file
            
        Returns:
            Dictionary with document metadata
        """
        file_path = Path(file_path)
        
        if not file_path.exists():
            raise FileNotFoundError(f"File not found: {file_path}")
        
        info = {
            'filename': file_path.name,
            'format': file_path.suffix.lower(),
            'size_bytes': file_path.stat().st_size,
            'size_mb': round(file_path.stat().st_size / (1024 * 1024), 2)
        }
        
        return info

