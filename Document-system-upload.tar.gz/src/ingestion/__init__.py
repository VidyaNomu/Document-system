"""
Document Ingestion Module

Handles loading documents from various sources and formats,
converting them to standardized image representations.
"""

from .document_loader import DocumentLoader

__all__ = ['DocumentLoader']

