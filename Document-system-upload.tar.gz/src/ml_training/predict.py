"""
Inference Script for LayoutLM Model

Use the trained LayoutLM model to extract fields from new invoices
"""

import json
import sys
import torch
from pathlib import Path
from PIL import Image
from typing import Dict, List
from transformers import LayoutLMv3Processor, LayoutLMv3ForTokenClassification

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from src.ingestion.document_loader import DocumentLoader
from src.preprocessing.image_preprocessor import ImagePreprocessor
from src.ocr.ocr_engine import OCREngine


class LayoutLMPredictor:
    """Predictor class for making inferences with trained LayoutLM model"""
    
    # Reverse label map
    ID_TO_LABEL = {
        0: 'O',
        1: 'invoice_number',
        2: 'invoice_date',
        3: 'seller_company',
        4: 'buyer_company',
        5: 'buyer_name',
        6: 'payment_total',
        7: 'payment_subtotal',
    }
    
    def __init__(self, model_path: str):
        """
        Initialize predictor
        
        Args:
            model_path: Path to trained model directory
        """
        self.model_path = Path(model_path)
        
        print(f"Loading model from {self.model_path}...")
        
        # Load processor and model
        self.processor = LayoutLMv3Processor.from_pretrained(str(self.model_path), apply_ocr=False)
        self.model = LayoutLMv3ForTokenClassification.from_pretrained(str(self.model_path))
        
        # Set to evaluation mode
        self.model.eval()
        
        # Use GPU if available
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.model.to(self.device)
        
        print(f"✓ Model loaded on {self.device}")
        
        # Initialize OCR pipeline
        self.loader = DocumentLoader(dpi=300)
        self.preprocessor = ImagePreprocessor(target_dpi=300)
        self.ocr = OCREngine(languages=['en'], gpu=False)
    
    def normalize_bbox(self, bbox: List, img_width: int, img_height: int) -> List[int]:
        """Normalize bounding box to 0-1000 scale"""
        xs = [point[0] for point in bbox]
        ys = [point[1] for point in bbox]
        
        x0, x1 = min(xs), max(xs)
        y0, y1 = min(ys), max(ys)
        
        # Normalize to 0-1000
        x0 = int((x0 / img_width) * 1000)
        x1 = int((x1 / img_width) * 1000)
        y0 = int((y0 / img_height) * 1000)
        y1 = int((y1 / img_height) * 1000)
        
        # Clamp
        x0 = max(0, min(1000, x0))
        x1 = max(0, min(1000, x1))
        y0 = max(0, min(1000, y0))
        y1 = max(0, min(1000, y1))
        
        return [x0, y0, x1, y1]
    
    def predict(self, image_path: str) -> Dict:
        """
        Predict fields for a single invoice
        
        Args:
            image_path: Path to invoice image
            
        Returns:
            Dictionary with extracted fields
        """
        # Load and preprocess image
        images = self.loader.load(str(image_path))
        img = images[0]
        img_width, img_height = img.size
        
        processed = self.preprocessor.preprocess(img)
        
        # Extract text with OCR
        ocr_results = self.ocr.extract_text(processed)
        
        if len(ocr_results) == 0:
            return {'error': 'No text detected'}
        
        # Prepare words and bboxes
        words = [block['text'].strip() for block in ocr_results]
        bboxes = [self.normalize_bbox(block['bbox'], img_width, img_height) for block in ocr_results]
        
        # Prepare input for model
        encoding = self.processor(
            img,
            words,
            boxes=bboxes,
            return_tensors='pt',
            padding='max_length',
            truncation=True,
            max_length=512
        )
        
        # Move to device
        encoding = {k: v.to(self.device) for k, v in encoding.items()}
        
        # Make prediction
        with torch.no_grad():
            outputs = self.model(**encoding)
        
        # Get predictions
        predictions = torch.argmax(outputs.logits, dim=2).squeeze().cpu().numpy()
        
        # Extract fields from predictions
        extracted_fields = self._extract_fields_from_predictions(words, predictions, encoding['attention_mask'].squeeze().cpu().numpy())
        
        return extracted_fields
    
    def _extract_fields_from_predictions(self, words: List[str], predictions: List[int], attention_mask: List[int]) -> Dict:
        """
        Extract structured fields from model predictions
        
        Args:
            words: List of words
            predictions: Predicted label IDs
            attention_mask: Attention mask (1 for real tokens, 0 for padding)
            
        Returns:
            Dictionary with extracted fields
        """
        fields = {
            'invoice': {'number': None, 'date': None},
            'seller': {'company_name': None},
            'buyer': {'name': None, 'company_name': None},
            'payment': {'total': None, 'sub_total': None}
        }
        
        # Process predictions
        for word, pred_id, mask in zip(words, predictions, attention_mask):
            if mask == 0:  # Skip padding
                continue
            
            label = self.ID_TO_LABEL.get(pred_id, 'O')
            
            if label == 'invoice_number' and not fields['invoice']['number']:
                fields['invoice']['number'] = word
            elif label == 'invoice_date' and not fields['invoice']['date']:
                fields['invoice']['date'] = word
            elif label == 'seller_company':
                if fields['seller']['company_name']:
                    fields['seller']['company_name'] += ' ' + word
                else:
                    fields['seller']['company_name'] = word
            elif label == 'buyer_name':
                if fields['buyer']['name']:
                    fields['buyer']['name'] += ' ' + word
                else:
                    fields['buyer']['name'] = word
            elif label == 'buyer_company':
                if fields['buyer']['company_name']:
                    fields['buyer']['company_name'] += ' ' + word
                else:
                    fields['buyer']['company_name'] = word
            elif label == 'payment_total' and not fields['payment']['total']:
                try:
                    fields['payment']['total'] = float(word.replace(',', '').replace('$', '').replace('€', ''))
                except:
                    pass
            elif label == 'payment_subtotal' and not fields['payment']['sub_total']:
                try:
                    fields['payment']['sub_total'] = float(word.replace(',', '').replace('$', '').replace('€', ''))
                except:
                    pass
        
        return fields


def main():
    """Main prediction function"""
    import argparse
    
    parser = argparse.ArgumentParser(description='Predict fields from invoice using trained LayoutLM model')
    parser.add_argument('--image', type=str, required=True, help='Path to invoice image')
    parser.add_argument('--model', type=str, default='models/layoutlm_invoice/final_model', help='Path to trained model')
    parser.add_argument('--compare', type=str, help='Path to ground truth JSON for comparison')
    
    args = parser.parse_args()
    
    # Check if model exists
    if not Path(args.model).exists():
        print(f"❌ Error: Model not found at {args.model}")
        print("Please train the model first:")
        print("  python src/ml_training/train_layoutlm.py")
        return
    
    print("="*70)
    print("LAYOUTLM INFERENCE")
    print("="*70)
    
    # Create predictor
    predictor = LayoutLMPredictor(args.model)
    
    # Make prediction
    print(f"\nProcessing: {args.image}")
    extracted = predictor.predict(args.image)
    
    # Display results
    print("\n" + "="*70)
    print("EXTRACTED FIELDS")
    print("="*70)
    print(json.dumps(extracted, indent=2))
    
    # Compare with ground truth if provided
    if args.compare:
        with open(args.compare, 'r') as f:
            ground_truth = json.load(f)
        
        print("\n" + "="*70)
        print("COMPARISON WITH GROUND TRUTH")
        print("="*70)
        
        # Compare fields
        def compare_field(field_name, extracted_val, gt_val):
            match = str(extracted_val).strip() == str(gt_val).strip()
            status = "✓" if match else "✗"
            print(f"{status} {field_name}:")
            print(f"    Extracted:    {extracted_val}")
            print(f"    Ground Truth: {gt_val}")
            return match
        
        matches = []
        
        matches.append(compare_field("Invoice Number", 
                                     extracted['invoice']['number'], 
                                     ground_truth['invoice']['number']))
        
        matches.append(compare_field("Invoice Date", 
                                     extracted['invoice']['date'], 
                                     ground_truth['invoice']['date']))
        
        matches.append(compare_field("Seller Company", 
                                     extracted['seller']['company_name'], 
                                     ground_truth['seller']['company_name']))
        
        matches.append(compare_field("Buyer Name", 
                                     extracted['buyer']['name'], 
                                     ground_truth['buyer']['name']))
        
        matches.append(compare_field("Payment Total", 
                                     extracted['payment']['total'], 
                                     ground_truth['payment']['total']))
        
        matches.append(compare_field("Payment Subtotal", 
                                     extracted['payment']['sub_total'], 
                                     ground_truth['payment']['sub_total']))
        
        accuracy = sum(matches) / len(matches) * 100
        print(f"\nAccuracy: {accuracy:.1f}% ({sum(matches)}/{len(matches)} fields)")


if __name__ == '__main__':
    main()

