"""
Train LayoutLMv3 Model for Invoice Field Extraction

Fine-tunes a pre-trained LayoutLMv3 model on invoice data
for token classification task (field extraction)
"""

import json
import torch
from pathlib import Path
from typing import Dict, List
from dataclasses import dataclass
from torch.utils.data import Dataset
from transformers import (
    LayoutLMv3Processor,
    LayoutLMv3ForTokenClassification,
    Trainer,
    TrainingArguments,
    EarlyStoppingCallback
)
from PIL import Image
import numpy as np


class InvoiceDataset(Dataset):
    """PyTorch Dataset for invoice data"""
    
    def __init__(self, data_file: str, processor, max_length: int = 512):
        """
        Initialize dataset
        
        Args:
            data_file: Path to JSON file with processed data
            processor: LayoutLMv3Processor instance
            max_length: Maximum sequence length
        """
        with open(data_file, 'r') as f:
            self.data = json.load(f)
        
        self.processor = processor
        self.max_length = max_length
    
    def __len__(self):
        return len(self.data)
    
    def __getitem__(self, idx):
        example = self.data[idx]
        
        # Load image
        image = Image.open(example['image_path']).convert('RGB')
        
        # Prepare encoding
        encoding = self.processor(
            image,
            example['words'],
            boxes=example['bboxes'],
            word_labels=example['labels'],
            padding='max_length',
            truncation=True,
            max_length=self.max_length,
            return_tensors='pt'
        )
        
        # Remove batch dimension
        for key in encoding.keys():
            encoding[key] = encoding[key].squeeze(0)
        
        return encoding


@dataclass
class ModelConfig:
    """Training configuration"""
    # Model
    model_name: str = "microsoft/layoutlmv3-base"
    num_labels: int = 8  # O, invoice_number, invoice_date, seller, buyer_company, buyer_name, total, subtotal
    
    # Training
    output_dir: str = "models/layoutlm_invoice"
    num_train_epochs: int = 10
    per_device_train_batch_size: int = 2  # Small batch due to large model
    per_device_eval_batch_size: int = 2
    learning_rate: float = 5e-5
    weight_decay: float = 0.01
    
    # Evaluation
    evaluation_strategy: str = "epoch"
    save_strategy: str = "epoch"
    load_best_model_at_end: bool = True
    metric_for_best_model: str = "f1"
    
    # Early stopping
    early_stopping_patience: int = 3
    
    # Logging
    logging_dir: str = "logs/layoutlm"
    logging_steps: int = 10
    
    # Other
    seed: int = 42
    fp16: bool = False  # Set to True if you have GPU with FP16 support


def compute_metrics(eval_pred):
    """
    Compute metrics for evaluation
    
    Args:
        eval_pred: Tuple of (predictions, labels)
        
    Returns:
        Dictionary with metrics
    """
    predictions, labels = eval_pred
    
    # Get predicted labels
    predictions = np.argmax(predictions, axis=2)
    
    # Remove padding (-100 labels)
    true_predictions = [
        [p for (p, l) in zip(prediction, label) if l != -100]
        for prediction, label in zip(predictions, labels)
    ]
    true_labels = [
        [l for (p, l) in zip(prediction, label) if l != -100]
        for prediction, label in zip(predictions, labels)
    ]
    
    # Flatten
    all_predictions = [p for pred in true_predictions for p in pred]
    all_labels = [l for label in true_labels for l in label]
    
    # Calculate metrics
    from sklearn.metrics import precision_recall_fscore_support, accuracy_score
    
    accuracy = accuracy_score(all_labels, all_predictions)
    precision, recall, f1, _ = precision_recall_fscore_support(
        all_labels, all_predictions, average='weighted', zero_division=0
    )
    
    return {
        'accuracy': accuracy,
        'precision': precision,
        'recall': recall,
        'f1': f1
    }


class LayoutLMTrainer:
    """Trainer class for LayoutLM model"""
    
    def __init__(self, config: ModelConfig):
        """
        Initialize trainer
        
        Args:
            config: Model configuration
        """
        self.config = config
        
        # Load processor
        print("Loading LayoutLMv3 processor...")
        self.processor = LayoutLMv3Processor.from_pretrained(
            config.model_name,
            apply_ocr=False  # We already have OCR results
        )
        
        # Load model
        print(f"Loading LayoutLMv3 model ({config.model_name})...")
        self.model = LayoutLMv3ForTokenClassification.from_pretrained(
            config.model_name,
            num_labels=config.num_labels
        )
        
        print("✓ Model and processor loaded")
    
    def load_datasets(self, train_file: str, val_file: str):
        """
        Load training and validation datasets
        
        Args:
            train_file: Path to training data JSON
            val_file: Path to validation data JSON
        """
        print(f"\nLoading datasets...")
        print(f"  Train: {train_file}")
        print(f"  Val:   {val_file}")
        
        self.train_dataset = InvoiceDataset(train_file, self.processor)
        self.val_dataset = InvoiceDataset(val_file, self.processor)
        
        print(f"✓ Loaded {len(self.train_dataset)} training examples")
        print(f"✓ Loaded {len(self.val_dataset)} validation examples")
    
    def train(self):
        """Train the model"""
        print(f"\n{'='*70}")
        print("STARTING TRAINING")
        print(f"{'='*70}\n")
        
        # Create output directory
        Path(self.config.output_dir).mkdir(parents=True, exist_ok=True)
        Path(self.config.logging_dir).mkdir(parents=True, exist_ok=True)
        
        # Training arguments
        training_args = TrainingArguments(
            output_dir=self.config.output_dir,
            num_train_epochs=self.config.num_train_epochs,
            per_device_train_batch_size=self.config.per_device_train_batch_size,
            per_device_eval_batch_size=self.config.per_device_eval_batch_size,
            learning_rate=self.config.learning_rate,
            weight_decay=self.config.weight_decay,
            evaluation_strategy=self.config.evaluation_strategy,
            save_strategy=self.config.save_strategy,
            load_best_model_at_end=self.config.load_best_model_at_end,
            metric_for_best_model=self.config.metric_for_best_model,
            logging_dir=self.config.logging_dir,
            logging_steps=self.config.logging_steps,
            seed=self.config.seed,
            fp16=self.config.fp16,
            report_to=["tensorboard"],
            save_total_limit=3,  # Keep only 3 best checkpoints
        )
        
        # Create trainer
        trainer = Trainer(
            model=self.model,
            args=training_args,
            train_dataset=self.train_dataset,
            eval_dataset=self.val_dataset,
            compute_metrics=compute_metrics,
            callbacks=[EarlyStoppingCallback(early_stopping_patience=self.config.early_stopping_patience)]
        )
        
        # Train
        print("Training model...")
        print(f"  Epochs: {self.config.num_train_epochs}")
        print(f"  Batch size: {self.config.per_device_train_batch_size}")
        print(f"  Learning rate: {self.config.learning_rate}")
        print(f"  Device: {'GPU' if torch.cuda.is_available() else 'CPU'}\n")
        
        trainer.train()
        
        print(f"\n{'='*70}")
        print("✓ TRAINING COMPLETE!")
        print(f"{'='*70}")
        
        # Save final model
        final_model_path = Path(self.config.output_dir) / "final_model"
        trainer.save_model(str(final_model_path))
        self.processor.save_pretrained(str(final_model_path))
        
        print(f"\n✓ Model saved to: {final_model_path}")
        
        # Evaluate on validation set
        print("\nFinal evaluation on validation set:")
        results = trainer.evaluate()
        
        for key, value in results.items():
            print(f"  {key}: {value:.4f}")
        
        return results


def main():
    """Main training function"""
    print("="*70)
    print("LAYOUTLM TRAINING FOR INVOICE FIELD EXTRACTION")
    print("="*70)
    
    # Configuration
    config = ModelConfig(
        model_name="microsoft/layoutlmv3-base",
        num_labels=8,
        num_train_epochs=10,
        per_device_train_batch_size=2,
        learning_rate=5e-5,
        output_dir="models/layoutlm_invoice",
        logging_dir="logs/layoutlm",
    )
    
    # Check if data exists
    train_file = "data/layoutlm_dataset/train.json"
    val_file = "data/layoutlm_dataset/val.json"
    
    if not Path(train_file).exists() or not Path(val_file).exists():
        print("\n❌ Error: Training data not found!")
        print("Please run the data preparation script first:")
        print("  python src/ml_training/prepare_data.py")
        return
    
    # Create trainer
    trainer = LayoutLMTrainer(config)
    
    # Load datasets
    trainer.load_datasets(train_file, val_file)
    
    # Train
    results = trainer.train()
    
    print("\n" + "="*70)
    print("NEXT STEPS:")
    print("="*70)
    print("1. Review training logs in logs/layoutlm/")
    print("2. Test the model with: python src/ml_training/predict.py")
    print("3. Evaluate on full dataset with: python src/ml_training/evaluate.py")
    
    return results


if __name__ == '__main__':
    main()

