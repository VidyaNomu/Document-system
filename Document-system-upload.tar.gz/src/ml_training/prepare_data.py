"""
Data Preparation for LayoutLM Training

Converts OCR results + ground truth JSON into LayoutLM format:
- Normalizes bounding boxes to 0-1000 scale
- Creates word-level labels for token classification
- Splits data into train/validation sets
"""

import json
import sys
from pathlib import Path
from typing import List, Dict, Tuple
import random
from collections import defaultdict

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from src.ingestion.document_loader import DocumentLoader
from src.preprocessing.image_preprocessor import ImagePreprocessor
from src.ocr.ocr_engine import OCREngine


class LayoutLMDataPreparator:
    """Prepare invoice data for LayoutLM training"""
    
    # Label mapping
    LABEL_MAP = {
        'O': 0,              # Other (default)
        'invoice_number': 1,
        'invoice_date': 2,
        'seller_company': 3,
        'buyer_company': 4,
        'buyer_name': 5,
        'payment_total': 6,
        'payment_subtotal': 7,
    }
    
    def __init__(self, image_dir: str, json_dir: str):
        """
        Initialize data preparator
        
        Args:
            image_dir: Directory containing invoice images
            json_dir: Directory containing ground truth JSON files
        """
        self.image_dir = Path(image_dir)
        self.json_dir = Path(json_dir)
        
        # Initialize pipeline
        self.loader = DocumentLoader(dpi=300)
        self.preprocessor = ImagePreprocessor(target_dpi=300)
        self.ocr = OCREngine(languages=['en'], gpu=False)
        
        print("✓ Data preparator initialized")
    
    def normalize_bbox(self, bbox: List[Tuple[int, int]], img_width: int, img_height: int) -> List[int]:
        """
        Normalize bounding box to 0-1000 scale (LayoutLM format)
        
        Args:
            bbox: List of (x, y) coordinates
            img_width: Image width in pixels
            img_height: Image height in pixels
            
        Returns:
            [x0, y0, x1, y1] in 0-1000 scale
        """
        # Get min/max coordinates
        xs = [point[0] for point in bbox]
        ys = [point[1] for point in bbox]
        
        x0, x1 = min(xs), max(xs)
        y0, y1 = min(ys), max(ys)
        
        # Normalize to 0-1000
        x0 = int((x0 / img_width) * 1000)
        x1 = int((x1 / img_width) * 1000)
        y0 = int((y0 / img_height) * 1000)
        y1 = int((y1 / img_height) * 1000)
        
        # Clamp to valid range
        x0 = max(0, min(1000, x0))
        x1 = max(0, min(1000, x1))
        y0 = max(0, min(1000, y0))
        y1 = max(0, min(1000, y1))
        
        return [x0, y0, x1, y1]
    
    def assign_labels(self, ocr_results: List[Dict], ground_truth: Dict) -> List[int]:
        """
        Assign labels to each OCR text block based on ground truth
        
        Args:
            ocr_results: List of OCR text blocks
            ground_truth: Ground truth data from JSON
            
        Returns:
            List of label IDs for each text block
        """
        labels = []
        
        for block in ocr_results:
            text = block['text'].strip()
            label = 'O'  # Default: Other
            
            # Check invoice number
            gt_inv_num = str(ground_truth.get('invoice', {}).get('number', '')).strip()
            if text == gt_inv_num:
                label = 'invoice_number'
            
            # Check invoice date
            gt_date = str(ground_truth.get('invoice', {}).get('date', '')).strip()
            if text == gt_date:
                label = 'invoice_date'
            
            # Check seller company (exact or substring)
            gt_seller = str(ground_truth.get('seller', {}).get('company_name', '')).strip()
            if gt_seller and (text == gt_seller or text in gt_seller or gt_seller in text):
                if len(text) > 5:  # Avoid matching short words
                    label = 'seller_company'
            
            # Check buyer company
            gt_buyer_company = str(ground_truth.get('buyer', {}).get('company_name', '')).strip()
            if gt_buyer_company and (text == gt_buyer_company or text in gt_buyer_company):
                if len(text) > 5:
                    label = 'buyer_company'
            
            # Check buyer name
            gt_buyer_name = str(ground_truth.get('buyer', {}).get('name', '')).strip()
            if gt_buyer_name and (text == gt_buyer_name or text in gt_buyer_name):
                if len(text) > 3:
                    label = 'buyer_name'
            
            # Check payment total (with tolerance)
            gt_total = ground_truth.get('payment', {}).get('total')
            if gt_total is not None:
                try:
                    text_num = float(text.replace(',', '').replace('$', '').replace('€', ''))
                    if abs(text_num - gt_total) < 0.01:
                        label = 'payment_total'
                except:
                    pass
            
            # Check payment subtotal
            gt_subtotal = ground_truth.get('payment', {}).get('sub_total')
            if gt_subtotal is not None:
                try:
                    text_num = float(text.replace(',', '').replace('$', '').replace('€', ''))
                    if abs(text_num - gt_subtotal) < 0.01:
                        label = 'payment_subtotal'
                except:
                    pass
            
            labels.append(self.LABEL_MAP[label])
        
        return labels
    
    def process_single_invoice(self, img_path: Path, gt_path: Path) -> Dict:
        """
        Process a single invoice and create LayoutLM training example
        
        Args:
            img_path: Path to invoice image
            gt_path: Path to ground truth JSON
            
        Returns:
            Dictionary with words, bboxes, labels, and metadata
        """
        # Load ground truth
        with open(gt_path, 'r') as f:
            ground_truth = json.load(f)
        
        # Load and preprocess image
        images = self.loader.load(str(img_path))
        img = images[0]
        img_width, img_height = img.size
        
        processed = self.preprocessor.preprocess(img)
        
        # Extract text with OCR
        ocr_results = self.ocr.extract_text(processed)
        
        if len(ocr_results) == 0:
            return None
        
        # Assign labels
        labels = self.assign_labels(ocr_results, ground_truth)
        
        # Extract words and normalized bboxes
        words = []
        bboxes = []
        
        for block in ocr_results:
            words.append(block['text'].strip())
            normalized_bbox = self.normalize_bbox(block['bbox'], img_width, img_height)
            bboxes.append(normalized_bbox)
        
        return {
            'id': img_path.stem,
            'words': words,
            'bboxes': bboxes,
            'labels': labels,
            'image_path': str(img_path),
        }
    
    def prepare_dataset(self, num_images: int = 100, train_split: float = 0.8) -> Tuple[List[Dict], List[Dict]]:
        """
        Prepare training and validation datasets
        
        Args:
            num_images: Number of images to process
            train_split: Fraction of data for training (rest for validation)
            
        Returns:
            Tuple of (train_dataset, val_dataset)
        """
        print(f"\n{'='*70}")
        print(f"PREPARING LAYOUTLM DATASET")
        print(f"{'='*70}\n")
        
        # Get all images
        all_images = sorted(self.image_dir.glob('*.png'), key=lambda x: int(x.stem))[:num_images]
        
        print(f"Processing {len(all_images)} invoices...")
        print(f"Train/Val split: {train_split:.0%} / {(1-train_split):.0%}\n")
        
        # Process each invoice
        dataset = []
        failed = 0
        
        for idx, img_path in enumerate(all_images, 1):
            try:
                gt_path = self.json_dir / f"{img_path.stem}.json"
                
                if not gt_path.exists():
                    print(f"[{idx}/{len(all_images)}] {img_path.name} - ✗ No ground truth")
                    failed += 1
                    continue
                
                example = self.process_single_invoice(img_path, gt_path)
                
                if example is None:
                    print(f"[{idx}/{len(all_images)}] {img_path.name} - ✗ OCR failed")
                    failed += 1
                    continue
                
                dataset.append(example)
                
                # Show label distribution for this example
                label_counts = defaultdict(int)
                for label in example['labels']:
                    label_name = [k for k, v in self.LABEL_MAP.items() if v == label][0]
                    label_counts[label_name] += 1
                
                print(f"[{idx}/{len(all_images)}] {img_path.name} - ✓ {len(example['words'])} words, labels: {dict(label_counts)}")
                
            except Exception as e:
                print(f"[{idx}/{len(all_images)}] {img_path.name} - ✗ Error: {e}")
                failed += 1
        
        print(f"\n{'='*70}")
        print(f"✓ Processed: {len(dataset)}/{len(all_images)} invoices")
        print(f"✗ Failed: {failed}/{len(all_images)} invoices")
        print(f"{'='*70}\n")
        
        # Shuffle and split
        random.shuffle(dataset)
        split_idx = int(len(dataset) * train_split)
        
        train_dataset = dataset[:split_idx]
        val_dataset = dataset[split_idx:]
        
        # Calculate label statistics
        print("Label distribution:")
        all_labels = [label for ex in train_dataset for label in ex['labels']]
        for label_name, label_id in self.LABEL_MAP.items():
            count = all_labels.count(label_id)
            pct = (count / len(all_labels) * 100) if len(all_labels) > 0 else 0
            print(f"  {label_name:<20} {count:>6} ({pct:>5.1f}%)")
        
        return train_dataset, val_dataset
    
    def save_datasets(self, train_dataset: List[Dict], val_dataset: List[Dict], output_dir: str):
        """
        Save datasets to JSON files
        
        Args:
            train_dataset: Training examples
            val_dataset: Validation examples
            output_dir: Output directory
        """
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        
        # Save training data
        train_path = output_path / 'train.json'
        with open(train_path, 'w') as f:
            json.dump(train_dataset, f, indent=2)
        
        # Save validation data
        val_path = output_path / 'val.json'
        with open(val_path, 'w') as f:
            json.dump(val_dataset, f, indent=2)
        
        # Save label map
        label_map_path = output_path / 'label_map.json'
        with open(label_map_path, 'w') as f:
            json.dump(self.LABEL_MAP, f, indent=2)
        
        print(f"\n✓ Datasets saved:")
        print(f"  Train: {train_path} ({len(train_dataset)} examples)")
        print(f"  Val:   {val_path} ({len(val_dataset)} examples)")
        print(f"  Labels: {label_map_path}")


def main():
    """Main function to prepare data"""
    # Configuration
    IMAGE_DIR = 'sample_documents/invoice_dataset/image'
    JSON_DIR = 'sample_documents/invoice_dataset/json'
    OUTPUT_DIR = 'data/layoutlm_dataset'
    NUM_IMAGES = 20  # Start with 20 for quick test (change to 100+ later)
    
    # Create preparator
    preparator = LayoutLMDataPreparator(IMAGE_DIR, JSON_DIR)
    
    # Prepare datasets
    train_dataset, val_dataset = preparator.prepare_dataset(
        num_images=NUM_IMAGES,
        train_split=0.8
    )
    
    # Save datasets
    preparator.save_datasets(train_dataset, val_dataset, OUTPUT_DIR)
    
    print(f"\n{'='*70}")
    print("✓ DATA PREPARATION COMPLETE!")
    print(f"{'='*70}")
    print("\nNext steps:")
    print("  1. Review the generated data in data/layoutlm_dataset/")
    print("  2. Run the training script: python src/ml_training/train_layoutlm.py")


if __name__ == '__main__':
    main()

