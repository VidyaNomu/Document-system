"""
Evaluation Script for LayoutLM Model

Evaluate the trained model on a test set and generate detailed metrics
"""

import json
import sys
from pathlib import Path
from typing import Dict, List
import numpy as np
from tqdm import tqdm

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from src.ml_training.predict import LayoutLMPredictor


class ModelEvaluator:
    """Evaluate trained LayoutLM model"""
    
    def __init__(self, model_path: str):
        """
        Initialize evaluator
        
        Args:
            model_path: Path to trained model
        """
        self.predictor = LayoutLMPredictor(model_path)
        
    def evaluate_single(self, image_path: str, ground_truth: Dict) -> Dict:
        """
        Evaluate on a single invoice
        
        Args:
            image_path: Path to invoice image
            ground_truth: Ground truth data
            
        Returns:
            Dictionary with comparison results
        """
        # Make prediction
        extracted = self.predictor.predict(image_path)
        
        # Compare fields
        comparison = {}
        
        # Invoice number
        ext_num = str(extracted.get('invoice', {}).get('number') or '').strip()
        gt_num = str(ground_truth.get('invoice', {}).get('number') or '').strip()
        comparison['invoice_number'] = (ext_num == gt_num) if ext_num and gt_num else False
        
        # Invoice date
        ext_date = str(extracted.get('invoice', {}).get('date') or '').strip()
        gt_date = str(ground_truth.get('invoice', {}).get('date') or '').strip()
        comparison['invoice_date'] = (ext_date == gt_date) if ext_date and gt_date else False
        
        # Seller company
        ext_seller = str((extracted.get('seller') or {}).get('company_name') or '').strip()
        gt_seller = str((ground_truth.get('seller') or {}).get('company_name') or '').strip()
        comparison['seller_company'] = (ext_seller == gt_seller) if ext_seller and gt_seller else False
        
        # Buyer name
        ext_buyer = str((extracted.get('buyer') or {}).get('name') or '').strip()
        gt_buyer = str((ground_truth.get('buyer') or {}).get('name') or '').strip()
        comparison['buyer_name'] = (ext_buyer == gt_buyer) if ext_buyer and gt_buyer else False
        
        # Payment total
        ext_total = (extracted.get('payment') or {}).get('total')
        gt_total = (ground_truth.get('payment') or {}).get('total')
        comparison['payment_total'] = abs(ext_total - gt_total) < 0.01 if ext_total and gt_total else False
        
        # Payment subtotal
        ext_sub = (extracted.get('payment') or {}).get('sub_total')
        gt_sub = (ground_truth.get('payment') or {}).get('sub_total')
        comparison['payment_subtotal'] = abs(ext_sub - gt_sub) < 0.01 if ext_sub and gt_sub else False
        
        return {
            'extracted': extracted,
            'ground_truth': ground_truth,
            'comparison': comparison
        }
    
    def evaluate_dataset(self, image_dir: str, json_dir: str, num_images: int = 50) -> Dict:
        """
        Evaluate on multiple invoices
        
        Args:
            image_dir: Directory with invoice images
            json_dir: Directory with ground truth JSON files
            num_images: Number of images to evaluate
            
        Returns:
            Dictionary with evaluation results
        """
        print(f"\n{'='*70}")
        print(f"EVALUATING MODEL ON {num_images} INVOICES")
        print(f"{'='*70}\n")
        
        image_dir = Path(image_dir)
        json_dir = Path(json_dir)
        
        # Get images
        images = sorted(image_dir.glob('*.png'), key=lambda x: int(x.stem))[:num_images]
        
        # Initialize results
        results = {
            'field_accuracy': {
                'invoice_number': {'correct': 0, 'total': 0},
                'invoice_date': {'correct': 0, 'total': 0},
                'seller_company': {'correct': 0, 'total': 0},
                'buyer_name': {'correct': 0, 'total': 0},
                'payment_total': {'correct': 0, 'total': 0},
                'payment_subtotal': {'correct': 0, 'total': 0},
            },
            'details': []
        }
        
        # Evaluate each invoice
        for img_path in tqdm(images, desc="Evaluating"):
            try:
                # Load ground truth
                gt_path = json_dir / f"{img_path.stem}.json"
                with open(gt_path, 'r') as f:
                    ground_truth = json.load(f)
                
                # Evaluate
                result = self.evaluate_single(str(img_path), ground_truth)
                
                # Update statistics
                for field, match in result['comparison'].items():
                    results['field_accuracy'][field]['total'] += 1
                    if match:
                        results['field_accuracy'][field]['correct'] += 1
                
                results['details'].append({
                    'filename': img_path.name,
                    **result
                })
                
            except Exception as e:
                print(f"\n✗ Error processing {img_path.name}: {e}")
        
        return results
    
    def print_results(self, results: Dict):
        """
        Print evaluation results
        
        Args:
            results: Evaluation results dictionary
        """
        print(f"\n{'='*70}")
        print("EVALUATION RESULTS")
        print(f"{'='*70}\n")
        
        # Field-by-field accuracy
        for field, stats in results['field_accuracy'].items():
            if stats['total'] > 0:
                acc = (stats['correct'] / stats['total']) * 100
                status = "✓" if acc == 100 else "⚠" if acc >= 80 else "✗"
                print(f"{status} {field:<20} {stats['correct']}/{stats['total']:<5} {acc:>6.1f}%")
        
        # Overall accuracy
        total_fields = sum(s['total'] for s in results['field_accuracy'].values())
        correct_fields = sum(s['correct'] for s in results['field_accuracy'].values())
        overall = (correct_fields / total_fields * 100) if total_fields > 0 else 0
        
        print("-"*70)
        print(f"  {'OVERALL':<20} {correct_fields}/{total_fields:<5} {overall:>6.1f}%")
        print(f"{'='*70}\n")
        
        # Calculate F1 scores
        print("F1 SCORES BY FIELD")
        print("-"*70)
        
        f1_scores = []
        for field_name, stats in results['field_accuracy'].items():
            if stats['total'] > 0:
                precision = stats['correct'] / stats['total']
                recall = precision  # Same in our case
                f1 = 2 * (precision * recall) / (precision + recall) if (precision + recall) > 0 else 0
                f1_scores.append(f1)
                
                status = "✓" if f1 >= 0.9 else "⚠" if f1 >= 0.7 else "✗"
                print(f"{status} {field_name:<20} F1: {f1:.3f} ({precision:.3f} precision)")
        
        macro_f1 = np.mean(f1_scores) if f1_scores else 0
        
        print(f"{'='*70}")
        print(f"🎯 MACRO-AVG F1 SCORE: {macro_f1:.3f}")
        print(f"🎯 OVERALL ACCURACY: {overall:.1f}%")
        print(f"{'='*70}\n")
        
        # Show some failures
        failures = [d for d in results['details'] if not all(d['comparison'].values())]
        if failures:
            print(f"SAMPLE FAILURES ({len(failures)} total):")
            print("-"*70)
            for detail in failures[:5]:  # Show first 5
                print(f"\n📄 {detail['filename']}:")
                for field, match in detail['comparison'].items():
                    if not match:
                        ext_val = self._get_field_value(detail['extracted'], field)
                        gt_val = self._get_field_value(detail['ground_truth'], field)
                        print(f"  ✗ {field}:")
                        print(f"    Extracted: '{ext_val}'")
                        print(f"    Expected:  '{gt_val}'")
    
    def _get_field_value(self, data: Dict, field: str):
        """Helper to get field value from nested dict"""
        if field == 'invoice_number':
            return data.get('invoice', {}).get('number')
        elif field == 'invoice_date':
            return data.get('invoice', {}).get('date')
        elif field == 'seller_company':
            return data.get('seller', {}).get('company_name')
        elif field == 'buyer_name':
            return data.get('buyer', {}).get('name')
        elif field == 'payment_total':
            return data.get('payment', {}).get('total')
        elif field == 'payment_subtotal':
            return data.get('payment', {}).get('sub_total')
        return None


def main():
    """Main evaluation function"""
    import argparse
    
    parser = argparse.ArgumentParser(description='Evaluate trained LayoutLM model')
    parser.add_argument('--model', type=str, default='models/layoutlm_invoice/final_model', help='Path to trained model')
    parser.add_argument('--images', type=str, default='sample_documents/invoice_dataset/image', help='Image directory')
    parser.add_argument('--json', type=str, default='sample_documents/invoice_dataset/json', help='JSON directory')
    parser.add_argument('--num', type=int, default=50, help='Number of invoices to evaluate')
    parser.add_argument('--output', type=str, help='Save results to JSON file')
    
    args = parser.parse_args()
    
    # Check if model exists
    if not Path(args.model).exists():
        print(f"❌ Error: Model not found at {args.model}")
        print("Please train the model first:")
        print("  python src/ml_training/train_layoutlm.py")
        return
    
    print("="*70)
    print("LAYOUTLM MODEL EVALUATION")
    print("="*70)
    
    # Create evaluator
    evaluator = ModelEvaluator(args.model)
    
    # Run evaluation
    results = evaluator.evaluate_dataset(args.images, args.json, args.num)
    
    # Print results
    evaluator.print_results(results)
    
    # Save results if requested
    if args.output:
        output_path = Path(args.output)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        
        with open(output_path, 'w') as f:
            json.dump(results, f, indent=2)
        
        print(f"✓ Results saved to: {output_path}")


if __name__ == '__main__':
    main()

