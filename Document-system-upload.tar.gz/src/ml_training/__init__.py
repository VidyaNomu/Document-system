"""
Machine Learning Training Module

Fine-tune LayoutLMv3 for invoice field extraction
"""

