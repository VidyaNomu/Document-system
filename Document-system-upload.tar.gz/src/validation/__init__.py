"""
Validation Module

Validates extracted data and ensures data quality.
"""

from .data_validator import DataValidator

__all__ = ['DataValidator']

