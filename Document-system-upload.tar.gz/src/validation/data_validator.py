"""
Data Validator

Validates extracted fields and ensures data quality.
"""

import re
from datetime import datetime
from typing import Dict, List, Any, Optional


class DataValidator:
    """
    Validates extracted document data.
    
    Checks for data consistency, format correctness, and business logic.
    """
    
    def __init__(self, min_confidence: float = 0.7):
        """
        Initialize validator.
        
        Args:
            min_confidence: Minimum confidence threshold for accepting fields
        """
        self.min_confidence = min_confidence
        self.validation_results = []
    
    def validate_all(self, extracted_fields: Dict[str, Any]) -> Dict[str, Any]:
        """
        Validate all extracted fields.
        
        Args:
            extracted_fields: Dictionary of extracted fields
            
        Returns:
            Validation report with issues and warnings
        """
        self.validation_results = []
        
        # Validate individual fields
        self._validate_invoice_number(extracted_fields.get('invoice_number'))
        self._validate_date(extracted_fields.get('date'))
        self._validate_amounts(extracted_fields)
        self._validate_vendor(extracted_fields.get('vendor'))
        
        # Check business logic
        self._validate_amount_logic(extracted_fields)
        
        # Generate report
        report = {
            'is_valid': all(r['severity'] != 'error' for r in self.validation_results),
            'issues': [r for r in self.validation_results if r['severity'] == 'error'],
            'warnings': [r for r in self.validation_results if r['severity'] == 'warning'],
            'info': [r for r in self.validation_results if r['severity'] == 'info']
        }
        
        return report
    
    def _add_result(self, field: str, severity: str, message: str):
        """Add validation result."""
        self.validation_results.append({
            'field': field,
            'severity': severity,
            'message': message
        })
    
    def _validate_invoice_number(self, invoice_number: Optional[str]):
        """Validate invoice number format."""
        if not invoice_number:
            self._add_result('invoice_number', 'error', 'Invoice number is missing')
            return
        
        # Check if it's numeric or alphanumeric
        if not re.match(r'^[A-Z0-9-]+$', str(invoice_number), re.IGNORECASE):
            self._add_result('invoice_number', 'warning', 
                           f'Invoice number has unusual format: {invoice_number}')
        
        # Check length
        if len(str(invoice_number)) < 3:
            self._add_result('invoice_number', 'warning', 
                           f'Invoice number seems too short: {invoice_number}')
    
    def _validate_date(self, date_str: Optional[str]):
        """Validate date format and reasonableness."""
        if not date_str:
            self._add_result('date', 'error', 'Date is missing')
            return
        
        # Try to parse date
        date_formats = [
            '%d.%m.%Y',  # 05.08.2007
            '%d/%m/%Y',  # 05/08/2007
            '%Y-%m-%d',  # 2007-08-05
            '%m/%d/%Y',  # 08/05/2007
        ]
        
        parsed_date = None
        for fmt in date_formats:
            try:
                parsed_date = datetime.strptime(date_str, fmt)
                break
            except ValueError:
                continue
        
        if not parsed_date:
            self._add_result('date', 'warning', f'Could not parse date: {date_str}')
            return
        
        # Check if date is reasonable (not in future, not too old)
        now = datetime.now()
        if parsed_date > now:
            self._add_result('date', 'warning', 'Date is in the future')
        
        years_old = (now - parsed_date).days / 365
        if years_old > 10:
            self._add_result('date', 'info', f'Invoice is {years_old:.1f} years old')
    
    def _validate_amounts(self, fields: Dict[str, Any]):
        """Validate amount fields."""
        # Check total
        if 'total' in fields:
            total_data = fields['total']
            amount = total_data.get('amount')
            confidence = total_data.get('confidence', 0)
            
            if amount is None:
                self._add_result('total', 'error', 'Total amount is missing')
            elif amount <= 0:
                self._add_result('total', 'error', f'Total amount is invalid: {amount}')
            elif confidence < self.min_confidence:
                self._add_result('total', 'warning', 
                               f'Total amount has low confidence: {confidence:.2%}')
        else:
            self._add_result('total', 'error', 'Total amount not found')
        
        # Check subtotal
        if 'subtotal' in fields:
            subtotal_data = fields['subtotal']
            confidence = subtotal_data.get('confidence', 0)
            
            if confidence < self.min_confidence:
                self._add_result('subtotal', 'warning', 
                               f'Subtotal has low confidence: {confidence:.2%}')
        
        # Check tax
        if 'tax' in fields:
            tax_data = fields['tax']
            confidence = tax_data.get('confidence', 0)
            
            if confidence < self.min_confidence:
                self._add_result('tax', 'warning', 
                               f'Tax has low confidence: {confidence:.2%}')
    
    def _validate_vendor(self, vendor: Optional[str]):
        """Validate vendor name."""
        if not vendor:
            self._add_result('vendor', 'warning', 'Vendor name not found')
            return
        
        # Check minimum length
        if len(vendor) < 3:
            self._add_result('vendor', 'warning', f'Vendor name seems too short: {vendor}')
    
    def _validate_amount_logic(self, fields: Dict[str, Any]):
        """Validate business logic for amounts."""
        # Check if subtotal + tax ≈ total
        if 'total' in fields and 'subtotal' in fields and 'tax' in fields:
            total = fields['total']['amount']
            subtotal = fields['subtotal']['amount']
            tax = fields['tax']['amount']
            
            expected_total = subtotal + tax
            difference = abs(total - expected_total)
            
            # Allow 1% tolerance for rounding
            tolerance = total * 0.01
            
            if difference > tolerance:
                self._add_result('amounts', 'warning', 
                               f'Amount mismatch: subtotal ({subtotal}) + tax ({tax}) '
                               f'!= total ({total}), difference: {difference:.2f}')
    
    def get_quality_score(self, fields: Dict[str, Any], 
                         validation_report: Dict[str, Any]) -> float:
        """
        Calculate overall data quality score (0-100).
        
        Args:
            fields: Extracted fields
            validation_report: Validation report
            
        Returns:
            Quality score from 0 to 100
        """
        score = 100.0
        
        # Deduct for errors
        score -= len(validation_report['issues']) * 15
        
        # Deduct for warnings
        score -= len(validation_report['warnings']) * 5
        
        # Bonus for having all key fields
        key_fields = ['invoice_number', 'date', 'total', 'vendor']
        present_fields = sum(1 for f in key_fields if f in fields and fields[f])
        score += (present_fields / len(key_fields)) * 10
        
        # Consider confidence scores
        if 'total' in fields and 'confidence' in fields['total']:
            score += fields['total']['confidence'] * 5
        
        # Clamp to 0-100
        return max(0, min(100, score))

