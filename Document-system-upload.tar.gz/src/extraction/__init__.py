"""
Field Extraction Module

Identifies and extracts specific fields from OCR text results.
"""

from .field_extractor import FieldExtractor

__all__ = ['FieldExtractor']

