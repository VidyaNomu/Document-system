"""
Field Extractor

Extracts structured fields from OCR text results using patterns and rules.
"""

import re
from datetime import datetime
from typing import List, Dict, Optional, Any
from difflib import SequenceMatcher


class FieldExtractor:
    """
    Extracts structured fields from OCR results.
    
    Identifies invoice numbers, dates, amounts, company names, etc.
    """
    
    def __init__(self):
        """Initialize the field extractor with patterns."""
        
        # Invoice number patterns
        self.invoice_patterns = [
            r'invoice[#\s:]*(\d+)',
            r'inv[#\s:]*(\d+)',
            r'#\s*(\d{5,})',
        ]
        
        # Date patterns
        self.date_patterns = [
            r'\d{1,2}[./]\d{1,2}[./]\d{2,4}',  # 05.08.2007, 5/8/2007
            r'\d{4}[-/]\d{1,2}[-/]\d{1,2}',     # 2007-08-05
        ]
        
        # Amount patterns (with currency symbols)
        self.amount_patterns = [
            r'[$€£¥]\s*[\d,]+\.?\d*',           # $534.11, €534.11
            r'[\d,]+\.?\d*\s*[$€£¥]',           # 534.11$
            r'[A-Z]?\s*[\d,]+\.\d{2}',          # E534.11, 534.11 (handles OCR errors)
            r'\b\d+\.\d{2}\b',                  # 534.11
        ]
        
        # Total/subtotal keywords
        self.total_keywords = ['total', 'amount due', 'balance', 'grand total']
        self.subtotal_keywords = ['subtotal', 'sub total', 'sub-total']
        
        # VAT/Tax keywords
        self.tax_keywords = ['vat', 'tax', 'gst', 'sales tax']
        
        # Discount keywords
        self.discount_keywords = ['discount']
        
        # Due/Balance keywords
        self.due_keywords = ['due', 'amount due', 'balance due']
        
        # VAT number patterns
        self.vat_patterns = [
            r'vat\s*(?:number|no|#)?[:\s]*([A-Z0-9]+)',
            r'(?:tax|tin)\s*(?:id|number|no)?[:\s]*([A-Z0-9]+)',
        ]
    
    def extract_all_fields(self, ocr_results: List[Dict]) -> Dict[str, Any]:
        """
        Extract all fields from OCR results.
        
        Args:
            ocr_results: List of OCR text blocks with text, bbox, confidence
            
        Returns:
            Dictionary with extracted fields
        """
        # Combine all text for pattern matching
        all_text_blocks = []
        for block in ocr_results:
            all_text_blocks.append({
                'text': block['text'],
                'confidence': block['confidence'],
                'bbox': block['bbox']
            })
        
        # Extract seller (vendor) info - usually at top
        seller_info = self.extract_seller_info(all_text_blocks)
        
        # Extract buyer info - usually middle section
        buyer_info = self.extract_buyer_info(all_text_blocks, seller_info)
        
        # Normalize company names
        seller_company = seller_info.get('company_name')
        if seller_company:
            seller_company = self.normalize_company_name(seller_company)
        
        # Extract fields matching ground truth structure EXACTLY
        fields = {
            'invoice': {
                'number': self.extract_invoice_number(all_text_blocks),
                'date': self.extract_date(all_text_blocks),
            },
            'seller': {
                'company_name': seller_company,
            },
            'buyer': {
                'name': buyer_info.get('name'),
            },
            'payment': {
                'total': self._get_amount_value(self.extract_total(all_text_blocks)),
                'sub_total': self._get_amount_value(self.extract_subtotal(all_text_blocks)),
            },
        }
        
        return fields
    
    def _get_amount_value(self, amount_dict: Optional[Dict]) -> Optional[float]:
        """Extract amount value from dict, return None if not found."""
        if amount_dict and isinstance(amount_dict, dict):
            return amount_dict.get('value') or amount_dict.get('amount')
        return None
    
    def extract_invoice_number(self, text_blocks: List[Dict]) -> Optional[str]:
        """Extract invoice number from text blocks."""
        for block in text_blocks:
            text = block['text'].lower()
            
            for pattern in self.invoice_patterns:
                match = re.search(pattern, text, re.IGNORECASE)
                if match:
                    return match.group(1) if match.lastindex else match.group(0)
        
        return None
    
    def extract_date(self, text_blocks: List[Dict]) -> Optional[str]:
        """Extract date from text blocks."""
        for block in text_blocks:
            text = block['text']
            
            # Look for "date" keyword nearby
            if 'date' in text.lower():
                for pattern in self.date_patterns:
                    match = re.search(pattern, text)
                    if match:
                        return match.group(0)
            
            # Try all blocks for date patterns
            for pattern in self.date_patterns:
                match = re.search(pattern, text)
                if match:
                    return match.group(0)
        
        return None
    
    def extract_total(self, text_blocks: List[Dict]) -> Optional[Dict]:
        """Extract total amount."""
        # Try exact "total" first (most common)
        result = self._extract_amount_near_keyword(text_blocks, ['total', 'grand total'])
        if result:
            return result
        # Fallback to other keywords
        return self._extract_amount_near_keyword(text_blocks, ['amount due', 'balance'])
    
    def extract_subtotal(self, text_blocks: List[Dict]) -> Optional[Dict]:
        """Extract subtotal amount."""
        return self._extract_amount_near_keyword(text_blocks, self.subtotal_keywords)
    
    def extract_tax(self, text_blocks: List[Dict]) -> Optional[Dict]:
        """Extract tax/VAT amount."""
        return self._extract_amount_near_keyword(text_blocks, self.tax_keywords)
    
    def _extract_amount_near_keyword(self, text_blocks: List[Dict], 
                                     keywords: List[str]) -> Optional[Dict]:
        """
        Find amount near specific keywords.
        
        Args:
            text_blocks: List of text blocks
            keywords: Keywords to look for (e.g., 'total', 'subtotal')
            
        Returns:
            Dict with amount value and confidence, or None
        """
        for i, block in enumerate(text_blocks):
            text = block['text'].lower()
            
            # Skip "subtotal" when looking for "total" (avoid substring match)
            if 'total' in keywords and 'subtotal' in text:
                continue
            
            # Check if this block contains the keyword
            if any(keyword in text for keyword in keywords):
                # Look for amount in same block
                amount = self._extract_amount_from_text(block['text'])
                if amount:
                    return {
                        'value': amount,
                        'confidence': block['confidence'],
                        'text': block['text']
                    }
                
                # Look in next block (amount might be separate)
                if i + 1 < len(text_blocks):
                    next_block = text_blocks[i + 1]
                    amount = self._extract_amount_from_text(next_block['text'])
                    if amount:
                        return {
                            'value': amount,
                            'confidence': next_block['confidence'],
                            'text': next_block['text']
                        }
        
        return None
    
    def _extract_amount_from_text(self, text: str) -> Optional[float]:
        """Extract numeric amount from text string."""
        for pattern in self.amount_patterns:
            match = re.search(pattern, text)
            if match:
                # Clean the matched string
                amount_str = match.group(0)
                # Remove currency symbols, letters, commas, and spaces
                amount_str = re.sub(r'[$€£¥,\sA-Z]', '', amount_str, flags=re.IGNORECASE)
                
                try:
                    return float(amount_str)
                except ValueError:
                    continue
        
        return None
    
    def extract_all_amounts(self, text_blocks: List[Dict]) -> List[float]:
        """Extract all numeric amounts from text."""
        amounts = []
        
        for block in text_blocks:
            amount = self._extract_amount_from_text(block['text'])
            if amount and amount > 0:
                amounts.append(amount)
        
        return amounts
    
    def extract_vendor(self, text_blocks: List[Dict]) -> Optional[str]:
        """
        Extract vendor/company name (usually at the top of invoice).
        
        Args:
            text_blocks: List of text blocks sorted by position
            
        Returns:
            Vendor name or None
        """
        # Sort by Y position (top to bottom)
        sorted_blocks = sorted(text_blocks, key=lambda x: x['bbox'][0][1])
        
        # Vendor is typically in first few blocks
        # Look for blocks with good confidence and reasonable length
        for block in sorted_blocks[:5]:
            text = block['text'].strip()
            
            # Skip common headers
            if any(skip in text.lower() for skip in ['invoice', 'receipt', 'bill']):
                continue
            
            # Vendor name is usually longer than 5 chars and has high confidence
            if len(text) > 5 and block['confidence'] > 0.85:
                return text
        
        return None
    
    def format_output(self, fields: Dict[str, Any]) -> Dict[str, Any]:
        """
        Format extracted fields into clean output.
        
        Args:
            fields: Raw extracted fields
            
        Returns:
            Formatted dictionary with clean data
        """
        output = {}
        
        # Invoice number
        if fields.get('invoice_number'):
            output['invoice_number'] = fields['invoice_number']
        
        # Date
        if fields.get('date'):
            output['date'] = fields['date']
        
        # Amounts
        if fields.get('total'):
            output['total'] = {
                'amount': fields['total']['value'],
                'confidence': fields['total']['confidence']
            }
        
        if fields.get('subtotal'):
            output['subtotal'] = {
                'amount': fields['subtotal']['value'],
                'confidence': fields['subtotal']['confidence']
            }
        
        if fields.get('tax'):
            output['tax'] = {
                'amount': fields['tax']['value'],
                'confidence': fields['tax']['confidence']
            }
        
        # Vendor
        if fields.get('vendor'):
            output['vendor'] = fields['vendor']
        
        # All amounts found
        if fields.get('amounts'):
            output['all_amounts'] = fields['amounts']
        
        return output
    
    def extract_seller_info(self, text_blocks: List[Dict]) -> Dict[str, Any]:
        """Extract seller/vendor information (top of invoice)."""
        # Sort by Y position (top to bottom)
        sorted_blocks = sorted(text_blocks, key=lambda x: x['bbox'][0][1])
        
        seller = {
            'company_name': None,
            'address': None,
            'vat_no': None
        }
        
        # Company name is usually first good text block at top
        skip_keywords = ['invoice', 'receipt', 'bill', 'date', 'number', 'vat', 'tax']
        
        for i, block in enumerate(sorted_blocks[:15]):  # Increased search range
            text = block['text'].strip()
            text_lower = text.lower()
            
            # Skip empty or very short text
            if len(text) < 3:
                continue
            
            # Check for VAT number first
            if 'vat' in text_lower or 'tax' in text_lower:
                for pattern in self.vat_patterns:
                    match = re.search(pattern, text, re.IGNORECASE)
                    if match:
                        seller['vat_no'] = match.group(1)
                continue
            
            # Skip common headers/keywords
            if any(skip in text_lower for skip in skip_keywords):
                continue
            
            # Look for company name indicators
            company_indicators = ['llc', 'inc', 'corp', 'ltd', 'plc', 'gmbh', ',', 'and']
            has_indicator = any(ind in text_lower for ind in company_indicators)
            
            # First good block with company indicator is likely the seller
            if not seller['company_name'] and has_indicator and len(text) > 5 and block['confidence'] > 0.75:
                seller['company_name'] = text
                
                # Next blocks might be address
                if i + 1 < len(sorted_blocks):
                    next_text = sorted_blocks[i + 1]['text'].strip()
                    # Address often contains numbers or specific keywords
                    if len(next_text) > 10 and (any(char.isdigit() for char in next_text) or 
                                                 any(word in next_text.lower() for word in ['street', 'avenue', 'road', 'drive', 'suite', 'unit'])):
                        seller['address'] = next_text
                break
            
            # Fallback: first substantial text with good confidence
            if not seller['company_name'] and len(text) > 8 and block['confidence'] > 0.85:
                seller['company_name'] = text
        
        return seller
    
    def extract_buyer_info(self, text_blocks: List[Dict], seller_info: Dict) -> Dict[str, Any]:
        """Extract buyer information (usually after seller)."""
        buyer = {
            'company_name': None,
            'name': None,
            'address': None,
            'country': None
        }
        
        # Sort by Y position for spatial analysis
        sorted_blocks = sorted(text_blocks, key=lambda x: x['bbox'][0][1])
        seller_company = seller_info.get('company_name', '')
        
        # Company name indicators
        company_indicators = ['LLC', 'Inc', 'Corp', 'Ltd', 'GmbH', 'PLC', 'Plc', 'llc', 'inc']
        
        # Buyer section indicators
        buyer_keywords = ['bill to', 'customer', 'client', 'buyer']
        
        # Find seller Y position to help locate buyer (buyer typically below seller)
        seller_y_pos = None
        if seller_company:
            for block in sorted_blocks[:15]:
                if self._text_similarity(block['text'].strip(), seller_company) > 0.9:
                    seller_y_pos = block['bbox'][0][1]
                    break
        
        # Strategy 1: Look for explicit buyer section markers
        buyer_section_idx = None
        for i, block in enumerate(sorted_blocks):
            text_lower = block['text'].lower()
            if any(keyword in text_lower for keyword in buyer_keywords):
                buyer_section_idx = i
                break
        
        # Strategy 2: Find companies that are not the seller
        # Start searching after seller or from buyer section
        start_idx = buyer_section_idx + 1 if buyer_section_idx is not None else 0
        
        # If we know seller position, only search blocks below it
        search_blocks = sorted_blocks[start_idx:]
        if seller_y_pos is not None:
            search_blocks = [b for b in search_blocks if b['bbox'][0][1] > seller_y_pos + 50]
        
        for i, block in enumerate(search_blocks):
            text = block['text'].strip()
            text_lower = text.lower()
            
            # Skip empty or very short text
            if len(text) < 3:
                continue
            
            # Skip if it's the seller company (exact or similar)
            if seller_company and self._text_similarity(text, seller_company) > 0.9:
                continue
            
            # Skip common keywords
            if any(skip in text_lower for skip in ['invoice', 'date', 'number', 'subtotal', 'total', 'vat', 'amount', 'due']):
                continue
            
            # Look for company name with indicators
            if any(indicator in text for indicator in company_indicators):
                if not buyer['company_name']:
                    buyer['company_name'] = text
                    block_idx = sorted_blocks.index(block)
                    
                    # Look for person name in next few blocks
                    for j in range(1, 5):
                        if block_idx + j < len(sorted_blocks):
                            next_block = sorted_blocks[block_idx + j]
                            next_text = next_block['text'].strip()
                            
                            # Person names are typically 2-3 words, have capital letters, no special chars
                            if self._looks_like_person_name(next_text) and not buyer['name']:
                                buyer['name'] = next_text
                            
                            # Address has numbers or keywords
                            elif len(next_text) > 10 and any(char.isdigit() for char in next_text) and not buyer['address']:
                                buyer['address'] = next_text
                            
                            # Country is often a single word or short phrase
                            elif len(next_text.split()) <= 2 and next_text and next_text[0].isupper() and not buyer['country']:
                                # Check if it's not a common invoice term
                                if next_text.lower() not in ['total', 'subtotal', 'invoice', 'date', 'amount']:
                                    buyer['country'] = next_text
                    break
        
        # Strategy 3: If no name found yet, look for person names in middle section
        if not buyer['name']:
            # Look in middle portion of document (between seller and line items)
            middle_start = 5  # Skip seller area
            middle_end = len(sorted_blocks) // 2  # Don't go into line items
            
            for i in range(middle_start, min(middle_end, len(sorted_blocks))):
                block = sorted_blocks[i]
                text = block['text'].strip()
                
                # Skip if it's the seller company
                if seller_company and self._text_similarity(text, seller_company) > 0.9:
                    continue
                
                # Skip if it has company indicators (we want person name, not company)
                if any(indicator in text for indicator in company_indicators):
                    continue
                
                # Look for person name patterns
                if self._looks_like_person_name(text):
                    buyer['name'] = text
                    break
        
        return buyer
    
    def _looks_like_person_name(self, text: str) -> bool:
        """Check if text looks like a person's name."""
        text = text.strip()
        
        # Should be 2-4 words
        words = text.split()
        if not (2 <= len(words) <= 4):
            return False
        
        # Should start with capital letters
        if not all(word[0].isupper() for word in words if word):
            return False
        
        # Should not contain numbers or special chars (except spaces, hyphens, apostrophes)
        if re.search(r'[0-9@#$%&*+=<>]', text):
            return False
        
        # Should not be common invoice terms
        text_lower = text.lower()
        if any(term in text_lower for term in ['invoice', 'total', 'subtotal', 'tax', 'date', 'amount', 'discount']):
            return False
        
        # Should not have company indicators
        if any(ind in text for ind in ['LLC', 'Inc', 'Corp', 'Ltd', 'PLC']):
            return False
        
        return True
    
    def _text_similarity(self, text1: str, text2: str) -> float:
        """Calculate similarity between two text strings using sequence matching."""
        if not text1 or not text2:
            return 0.0
        
        text1 = text1.lower().strip()
        text2 = text2.lower().strip()
        
        if text1 == text2:
            return 1.0
        
        # Use SequenceMatcher for better fuzzy matching
        return SequenceMatcher(None, text1, text2).ratio()
    
    def fuzzy_match_field(self, extracted: str, candidates: List[str], threshold: float = 0.85) -> Optional[str]:
        """
        Fuzzy match extracted text against candidates.
        
        Args:
            extracted: Extracted text from OCR
            candidates: List of possible correct values
            threshold: Minimum similarity threshold (0-1)
            
        Returns:
            Best matching candidate or None
        """
        if not extracted or not candidates:
            return None
        
        best_match = None
        best_score = 0.0
        
        for candidate in candidates:
            score = self._text_similarity(extracted, candidate)
            if score > best_score and score >= threshold:
                best_score = score
                best_match = candidate
        
        return best_match
    
    def normalize_company_name(self, name: str) -> str:
        """
        Normalize company name by handling common OCR errors.
        
        Args:
            name: Company name from OCR
            
        Returns:
            Normalized company name
        """
        if not name:
            return name
        
        # Common OCR error corrections
        corrections = {
            r'\s+': ' ',  # Multiple spaces to single space
            r'L\.L\.C\.': 'LLC',  # L.L.C. to LLC
            r'lnc': 'Inc',  # Common OCR error
            r'Plc\.': 'PLC',
            r'\s*,\s*': ', ',  # Normalize commas
        }
        
        normalized = name.strip()
        for pattern, replacement in corrections.items():
            normalized = re.sub(pattern, replacement, normalized)
        
        return normalized
    
    def extract_discount(self, text_blocks: List[Dict]) -> Optional[Dict]:
        """Extract discount amount."""
        return self._extract_amount_near_keyword(text_blocks, self.discount_keywords)
    
    def extract_due(self, text_blocks: List[Dict]) -> Optional[Dict]:
        """Extract amount due."""
        return self._extract_amount_near_keyword(text_blocks, self.due_keywords)

