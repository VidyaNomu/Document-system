"""
Image Preprocessing Module

Handles deskewing, denoising, contrast enhancement, and binarization
of document images to improve OCR accuracy.
"""

import cv2
import numpy as np
from PIL import Image
from typing import Tuple


class ImagePreprocessor:
    """
    Preprocesses document images for OCR.
    
    Applies deskewing, denoising, contrast enhancement, and binarization
    to improve text recognition accuracy.
    """
    
    def __init__(self, target_dpi: int = 300):
        """
        Initialize preprocessor.
        
        Args:
            target_dpi: Target DPI for output images (default: 300)
        """
        self.target_dpi = target_dpi
    
    def preprocess(self, image: Image.Image, enable_deskew: bool = True) -> Image.Image:
        """
        Apply full preprocessing pipeline to an image.
        
        Args:
            image: PIL Image to preprocess
            enable_deskew: Whether to apply deskewing (default: True)
            
        Returns:
            Preprocessed PIL Image
        """
        # Convert PIL to OpenCV format
        img_cv = self._pil_to_cv(image)
        
        # Apply preprocessing steps
        if enable_deskew:
            img_cv = self.deskew(img_cv)
        
        img_cv = self.denoise(img_cv)
        img_cv = self.enhance_contrast(img_cv)
        img_cv = self.binarize(img_cv)
        
        # Convert back to PIL
        img_pil = self._cv_to_pil(img_cv)
        
        return img_pil
    
    def deskew(self, image: np.ndarray) -> np.ndarray:
        """
        Detect and correct skew angle in document image.
        
        Args:
            image: OpenCV image (numpy array)
            
        Returns:
            Deskewed image
        """
        # Convert to grayscale if needed
        if len(image.shape) == 3:
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        else:
            gray = image.copy()
        
        # Apply edge detection
        edges = cv2.Canny(gray, 50, 150, apertureSize=3)
        
        # Detect lines using Hough transform
        lines = cv2.HoughLines(edges, 1, np.pi / 180, 200)
        
        if lines is None:
            return image  # No lines detected, return original
        
        # Calculate angles
        angles = []
        for rho, theta in lines[:, 0]:
            angle = np.degrees(theta) - 90
            angles.append(angle)
        
        # Get median angle
        if len(angles) == 0:
            return image
        
        median_angle = np.median(angles)
        
        # Only correct if angle is significant (> 0.5 degrees)
        if abs(median_angle) < 0.5:
            return image
        
        # Rotate image
        height, width = image.shape[:2]
        center = (width // 2, height // 2)
        rotation_matrix = cv2.getRotationMatrix2D(center, median_angle, 1.0)
        rotated = cv2.warpAffine(image, rotation_matrix, (width, height), 
                                  flags=cv2.INTER_CUBIC,
                                  borderMode=cv2.BORDER_REPLICATE)
        
        return rotated
    
    def denoise(self, image: np.ndarray) -> np.ndarray:
        """
        Remove noise from image using Non-local Means Denoising.
        
        Args:
            image: OpenCV image
            
        Returns:
            Denoised image
        """
        if len(image.shape) == 3:
            # Color image
            denoised = cv2.fastNlMeansDenoisingColored(image, None, 10, 10, 7, 21)
        else:
            # Grayscale image
            denoised = cv2.fastNlMeansDenoising(image, None, 10, 7, 21)
        
        return denoised
    
    def enhance_contrast(self, image: np.ndarray) -> np.ndarray:
        """
        Enhance image contrast using CLAHE (Contrast Limited Adaptive Histogram Equalization).
        
        Args:
            image: OpenCV image
            
        Returns:
            Contrast-enhanced image
        """
        # Convert to grayscale if needed
        if len(image.shape) == 3:
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        else:
            gray = image.copy()
        
        # Apply CLAHE
        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
        enhanced = clahe.apply(gray)
        
        return enhanced
    
    def binarize(self, image: np.ndarray) -> np.ndarray:
        """
        Convert image to binary (black text on white background) using Otsu's method.
        
        Args:
            image: OpenCV image
            
        Returns:
            Binarized image
        """
        # Convert to grayscale if needed
        if len(image.shape) == 3:
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        else:
            gray = image.copy()
        
        # Apply Gaussian blur to reduce noise before binarization
        blurred = cv2.GaussianBlur(gray, (5, 5), 0)
        
        # Apply Otsu's thresholding
        _, binary = cv2.threshold(blurred, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        
        return binary
    
    def _pil_to_cv(self, pil_image: Image.Image) -> np.ndarray:
        """Convert PIL Image to OpenCV format."""
        return cv2.cvtColor(np.array(pil_image), cv2.COLOR_RGB2BGR)
    
    def _cv_to_pil(self, cv_image: np.ndarray) -> Image.Image:
        """Convert OpenCV image to PIL format."""
        if len(cv_image.shape) == 2:
            # Grayscale
            return Image.fromarray(cv_image)
        else:
            # Color
            return Image.fromarray(cv2.cvtColor(cv_image, cv2.COLOR_BGR2RGB))