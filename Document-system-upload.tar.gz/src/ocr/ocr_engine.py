"""
OCR Engine using EasyOCR

Extracts text with positions and confidence scores from images.
"""

import easyocr
from PIL import Image
import numpy as np
from typing import List, Dict


class OCREngine:
    """
    OCR engine powered by EasyOCR for text extraction.
    """
    
    def __init__(self, languages: List[str] = ['en'], gpu: bool = False):
        """
        Initialize OCR engine.
        
        Args:
            languages: List of language codes (default: ['en'] for English)
            gpu: Use GPU if available (default: False)
        """
        print(f"Initializing EasyOCR for languages: {languages}...")
        self.reader = easyocr.Reader(languages, gpu=gpu)
        print("✓ OCR engine ready")
    
    def extract_text(self, image: Image.Image, detail: int = 1) -> List[Dict]:
        """
        Extract text from image with positions and confidence.
        
        Args:
            image: PIL Image to process
            detail: Level of detail (0=text only, 1=text+bbox+conf)
            
        Returns:
            List of dictionaries with text, bounding box, and confidence
        """
        # Convert PIL to numpy array
        img_array = np.array(image)
        
        # Run OCR
        results = self.reader.readtext(img_array, detail=detail)
        
        # Parse results
        extracted = []
        for result in results:
            if detail == 1:
                bbox, text, confidence = result
                extracted.append({
                    'text': text,
                    'bbox': bbox,  # [[x1,y1], [x2,y2], [x3,y3], [x4,y4]]
                    'confidence': float(confidence)
                })
            else:
                extracted.append({'text': result})
        
        return extracted
    
    def extract_text_simple(self, image: Image.Image) -> str:
        """
        Extract just the text as a single string.
        
        Args:
            image: PIL Image to process
            
        Returns:
            Extracted text as string
        """
        results = self.extract_text(image, detail=0)
        return '\n'.join([r['text'] for r in results])
    
    def get_text_blocks(self, image: Image.Image, min_confidence: float = 0.5) -> List[Dict]:
        """
        Get text blocks with filtering by confidence.
        
        Args:
            image: PIL Image to process
            min_confidence: Minimum confidence threshold (0.0 to 1.0)
            
        Returns:
            List of text blocks with high confidence
        """
        results = self.extract_text(image, detail=1)
        
        # Filter by confidence
        filtered = [r for r in results if r['confidence'] >= min_confidence]
        
        return filtered

