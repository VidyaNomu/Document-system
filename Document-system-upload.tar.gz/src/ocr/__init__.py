"""
OCR Module

Extracts text from preprocessed document images using EasyOCR.
"""

from .ocr_engine import OCREngine

__all__ = ['OCREngine']
